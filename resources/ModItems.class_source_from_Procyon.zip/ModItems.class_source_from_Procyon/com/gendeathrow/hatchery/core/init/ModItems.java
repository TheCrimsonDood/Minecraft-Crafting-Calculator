// 
// Decompiled by Procyon v0.5.36
// 

package com.gendeathrow.hatchery.core.init;

import com.gendeathrow.hatchery.item.upgrades.BaseUpgrade;
import com.gendeathrow.hatchery.item.Wrench;
import com.gendeathrow.hatchery.item.ItemChickenMachine;
import com.gendeathrow.hatchery.item.PrizeEgg;
import com.gendeathrow.hatchery.item.Sprayer;
import com.gendeathrow.hatchery.item.ChickenManure;
import com.gendeathrow.hatchery.item.AnimalNet;
import com.gendeathrow.hatchery.item.HatcheryEgg;
import java.util.ArrayList;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;
import net.minecraft.client.renderer.color.IItemColor;
import com.gendeathrow.hatchery.client.IItemColorHandler;
import net.minecraftforge.fml.client.FMLClientHandler;
import java.util.Iterator;
import java.lang.reflect.Field;
import net.minecraftforge.client.model.ModelLoader;
import net.minecraft.client.renderer.block.model.ModelResourceLocation;
import net.minecraft.item.ItemStack;
import net.minecraft.util.NonNullList;
import net.minecraftforge.client.event.ModelRegistryEvent;
import net.minecraftforge.registries.IForgeRegistryEntry;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.event.RegistryEvent;
import com.gendeathrow.hatchery.Hatchery;
import net.minecraft.util.ResourceLocation;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraft.item.Item;
import java.util.List;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class ModItems
{
    public static final List<Item> ITEMS;
    public static Item hatcheryEgg;
    public static Item animalNet;
    public static Item manure;
    public static Item sprayer;
    public static Item featherMeal;
    public static Item plastic;
    public static Item featherFiber;
    public static Item chickenFeed;
    public static Item circuitBoard;
    public static Item fiberPad;
    public static Item mealPulp;
    public static Item prizeEgg;
    public static Item chickenmachine;
    public static Item wrench;
    public static Item rfUpgradeTier;
    public static Item speedUpgradeTier;
    public static Item tankUpgradeTier1;
    public static Item rfCapacityUpgradeTier1;
    public static IForgeRegistry<Item> itemRegistry;
    
    public static Item setUpItem(final Item item, final String name) {
        return ((Item)item.setRegistryName(new ResourceLocation("hatchery", name))).func_77655_b("hatchery." + name).func_77637_a(Hatchery.hatcheryTabs);
    }
    
    @SubscribeEvent
    public static void itemRegistry(final RegistryEvent.Register<Item> event) {
        ModItems.itemRegistry = (IForgeRegistry<Item>)event.getRegistry();
        registerAllItems(ModItems.hatcheryEgg, ModItems.animalNet, ModItems.manure, ModItems.sprayer, ModItems.featherMeal, ModItems.plastic, ModItems.featherFiber, ModItems.chickenFeed, ModItems.circuitBoard, ModItems.fiberPad, ModItems.mealPulp, ModItems.prizeEgg, ModItems.chickenmachine, ModItems.rfUpgradeTier, ModItems.speedUpgradeTier, ModItems.tankUpgradeTier1, ModItems.rfCapacityUpgradeTier1);
        ModBlocks.registerItems((RegistryEvent.Register)event);
    }
    
    public static void registerAllItems(final Item... items) {
        for (final Item item : items) {
            ModItems.itemRegistry.register((IForgeRegistryEntry)item);
            ModItems.ITEMS.add(item);
        }
    }
    
    @SubscribeEvent
    public static void registerModels(final ModelRegistryEvent event) {
        try {
            for (final Field field : ModItems.class.getDeclaredFields()) {
                final Object obj = field.get(null);
                if (obj instanceof Item) {
                    final Item item = (Item)obj;
                    final NonNullList<ItemStack> list = (NonNullList<ItemStack>)NonNullList.func_191196_a();
                    item.func_150895_a(Hatchery.hatcheryTabs, (NonNullList)list);
                    if (list.size() > 1) {
                        for (final ItemStack metaitem : list) {
                            ModelLoader.setCustomModelResourceLocation(item, metaitem.func_77960_j(), new ModelResourceLocation(item.getRegistryName() + "_" + metaitem.func_77960_j(), "inventory"));
                        }
                    }
                    else {
                        ModelLoader.setCustomModelResourceLocation(item, 0, new ModelResourceLocation(item.getRegistryName(), "inventory"));
                    }
                }
            }
        }
        catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        }
    }
    
    @SideOnly(Side.CLIENT)
    public static void registerItemColorHandler(final Item item) {
        FMLClientHandler.instance().getClient().getItemColors().func_186730_a((IItemColor)new IItemColorHandler(), new Item[] { ModItems.hatcheryEgg });
    }
    
    static {
        ITEMS = new ArrayList<Item>();
        ModItems.hatcheryEgg = setUpItem((Item)new HatcheryEgg(), "hatcheryegg");
        ModItems.animalNet = setUpItem((Item)new AnimalNet(), "animalnet");
        ModItems.manure = setUpItem((Item)new ChickenManure(), "chickenmanure");
        ModItems.sprayer = setUpItem((Item)new Sprayer(), "sprayer");
        ModItems.featherMeal = setUpItem(new Item(), "feather_meal");
        ModItems.plastic = setUpItem(new Item(), "plastic");
        ModItems.featherFiber = setUpItem(new Item(), "feather_fiber");
        ModItems.chickenFeed = setUpItem(new Item(), "chicken_feed");
        ModItems.circuitBoard = setUpItem(new Item(), "circuit_board");
        ModItems.fiberPad = setUpItem(new Item(), "fiber_pad");
        ModItems.mealPulp = setUpItem(new Item(), "feather_pulp");
        ModItems.prizeEgg = setUpItem((Item)new PrizeEgg(), "prize_egg");
        ModItems.chickenmachine = setUpItem((Item)new ItemChickenMachine(), "chicken_machine");
        ModItems.wrench = setUpItem((Item)new Wrench(), "wrench");
        ModItems.rfUpgradeTier = setUpItem((Item)new BaseUpgrade(3, "rf_upgrade"), "rf_upgrade");
        ModItems.speedUpgradeTier = setUpItem((Item)new BaseUpgrade(3, "speed_upgrade"), "speed_upgrade");
        ModItems.tankUpgradeTier1 = setUpItem((Item)new BaseUpgrade(3, "tank_upgrade"), "tank_upgrade");
        ModItems.rfCapacityUpgradeTier1 = setUpItem((Item)new BaseUpgrade(3, "rf_capacity_upgrade"), "rf_capacity_upgrade");
    }
}
