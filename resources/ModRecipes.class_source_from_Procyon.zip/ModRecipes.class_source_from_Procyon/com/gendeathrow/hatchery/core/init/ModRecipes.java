// 
// Decompiled by Procyon v0.5.36
// 

package com.gendeathrow.hatchery.core.init;

import java.util.ArrayList;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import java.util.Iterator;
import net.minecraftforge.registries.IForgeRegistryEntry;
import com.gendeathrow.hatchery.block.shredder.ShredderTileEntity;
import net.minecraftforge.event.RegistryEvent;
import net.minecraft.item.crafting.Ingredient;
import net.minecraft.item.crafting.ShapelessRecipes;
import net.minecraft.util.NonNullList;
import net.minecraft.item.Item;
import net.minecraftforge.oredict.ShapedOreRecipe;
import net.minecraft.util.ResourceLocation;
import net.minecraft.item.crafting.ShapedRecipes;
import net.minecraftforge.common.crafting.CraftingHelper;
import net.minecraftforge.fml.common.registry.GameRegistry;
import net.minecraft.init.Items;
import net.minecraft.init.Blocks;
import net.minecraft.item.ItemStack;
import net.minecraftforge.oredict.OreDictionary;
import java.util.List;
import net.minecraft.item.crafting.IRecipe;
import net.minecraftforge.registries.IForgeRegistry;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber
public class ModRecipes
{
    public static IForgeRegistry<IRecipe> recipeRegistry;
    public static List<IRecipe> RECIPELIST;
    
    public static void RegisterOreDic() {
        OreDictionary.registerOre("dirt", ModBlocks.fertlizedDirt);
        OreDictionary.registerOre("fertilizedDirt", ModBlocks.fertlizedDirt);
        OreDictionary.registerOre("manure", ModItems.manure);
        OreDictionary.registerOre("manureBlock", ModBlocks.manureBlock);
        OreDictionary.registerOre("egg", ModItems.hatcheryEgg);
        OreDictionary.registerOre("listAllegg", ModItems.hatcheryEgg);
        OreDictionary.registerOre("plasticEgg", ModItems.prizeEgg);
    }
    
    public static void initRecipes() {
        addShapedOreRecipe("net_recipe", "held", new ItemStack(ModItems.animalNet), new Object[] { " SS", "SAA", "  A", 'S', "stickWood", 'A', "string" });
        addShapedOreRecipe("luckyegg_machine_recipe", "machine", new ItemStack(ModItems.chickenmachine), new Object[] { " W ", "WEW", "ICI", 'W', "plankWood", 'E', "egg", 'I', Blocks.field_150339_S, 'C', ModItems.circuitBoard });
        addShapedOreRecipe("nestingpen_recipe", "block", new ItemStack(ModBlocks.pen), new Object[] { "W W", "WNW", "WWW", 'W', "plankWood", 'N', ModBlocks.nest });
        addShapedOreRecipe("dirt_recipe", "block", new ItemStack(ModBlocks.fertlizedDirt), new Object[] { "PPP", "PDP", "PPP", 'P', "manure", 'D', "dirt" });
        addShapedOreRecipe("feeder_recipe", "machine", new ItemStack(ModBlocks.feeder), new Object[] { " I ", "SBS", "SSS", 'I', "ingotIron", 'B', "blockIron", 'S', "slabWood" });
        addShapedOreRecipe("nursery_block_recipe", "machine", new ItemStack(ModBlocks.nuseryBlock), new Object[] { "III", "IPI", "SSS", 'I', "ingotIron", 'P', Blocks.field_150331_J, 'S', "slabWood" });
        addShapedOreRecipe("nest_recipe", "held", new ItemStack(ModItems.sprayer), new Object[] { "DD ", " IB", "IGI", 'I', "ingotIron", 'G', ModFluids.getFertilizerBucket(), 'D', "ingotIron", 'B', new ItemStack(Blocks.field_150430_aB) });
        addShapedRecipes("nest_recipe", "held", new ItemStack(ModBlocks.nest), "   ", "A A", " A ", 'A', Blocks.field_150407_cf);
        addShapedRecipes("manureitem_to_block", "held", new ItemStack(ModBlocks.manureBlock), "XXX", "XXX", "XXX", 'X', ModItems.manure);
        addShapelessRecipes("manureblock_to_item", "held", new ItemStack(ModItems.manure, 9), new ItemStack(ModBlocks.manureBlock));
        addShapedRecipes("digeter_gen_recipe", "machine", new ItemStack(ModBlocks.digesterGenerator), "III", "PRB", "I I", 'I', Items.field_151042_j, 'R', Blocks.field_150451_bX, 'P', Blocks.field_150331_J, 'B', Items.field_151133_ar);
        addShapedRecipes("mixer_recipe", "machine", new ItemStack(ModBlocks.fertilizerMixer), " H ", "IPI", "IBI", 'H', Blocks.field_150438_bZ, 'I', Items.field_151042_j, 'P', Blocks.field_150331_J, 'B', Items.field_151133_ar);
        addShapedRecipes("rfupgrade_1_recipe", "upgrade", new ItemStack(ModItems.rfUpgradeTier), "TRT", "RGR", "TRT", 'T', Blocks.field_150429_aA, 'R', Items.field_151137_ax, 'G', ModItems.circuitBoard);
        addShapedRecipes("rfupgrade_2_recipe", "upgrade", new ItemStack(ModItems.rfUpgradeTier, 1, 1), "SXS", "RUR", "GXG", 'S', Items.field_151114_aO, 'U', ModItems.rfUpgradeTier, 'R', Items.field_151137_ax, 'X', ModItems.circuitBoard, 'G', Items.field_151043_k);
        addShapedRecipes("rfupgrade_3_recipe", "upgrade", new ItemStack(ModItems.rfUpgradeTier, 1, 2), "EXD", "XUX", "GXG", 'E', Items.field_151166_bC, 'D', Items.field_151045_i, 'U', new ItemStack(ModItems.rfUpgradeTier, 1, 1), 'X', ModItems.circuitBoard, 'G', Blocks.field_150340_R);
        addShapedRecipes("rfcapupgrade_1_recipe", "upgrade", new ItemStack(ModItems.rfCapacityUpgradeTier1), "XRX", "XGX", "XTX", 'T', Blocks.field_150429_aA, 'R', Items.field_151137_ax, 'X', Blocks.field_150405_ch, 'G', ModItems.circuitBoard);
        addShapedRecipes("rfcapupgrade_2_recipe", "upgrade", new ItemStack(ModItems.rfCapacityUpgradeTier1, 1, 1), "BTB", "RGR", "TCT", 'T', Items.field_151079_bi, 'R', Blocks.field_150451_bX, 'C', Blocks.field_150405_ch, 'B', ModItems.circuitBoard, 'G', new ItemStack(ModItems.rfCapacityUpgradeTier1));
        addShapedRecipes("rfcapupgrade_3_recipe", "upgrade", new ItemStack(ModItems.rfCapacityUpgradeTier1, 1, 2), "TBT", "RGR", "TCT", 'T', Items.field_185161_cS, 'R', Blocks.field_150451_bX, 'C', Blocks.field_180397_cI, 'B', ModItems.circuitBoard, 'G', new ItemStack(ModItems.rfCapacityUpgradeTier1, 1, 1));
        addShapedRecipes("tank_1_recipe", "upgrade", new ItemStack(ModItems.tankUpgradeTier1), "BBB", "BGB", "BBB", 'B', Items.field_151133_ar, 'G', ModItems.circuitBoard);
        addShapedRecipes("tank_2_recipe", "upgrade", new ItemStack(ModItems.tankUpgradeTier1, 1, 1), "IBI", "OGO", "CCC", 'C', Blocks.field_150339_S, 'B', Items.field_151133_ar, 'I', Items.field_151042_j, 'O', ModItems.circuitBoard, 'G', new ItemStack(ModItems.tankUpgradeTier1, 1, 0));
        addShapedRecipes("tank_3_recipe", "upgrade", new ItemStack(ModItems.tankUpgradeTier1, 1, 2), "BCB", "BGB", "OCO", 'B', Blocks.field_150339_S, 'C', Items.field_151066_bu, 'O', ModItems.circuitBoard, 'G', new ItemStack(ModItems.tankUpgradeTier1, 1, 1));
        addShapedRecipes("speed_1_recipe", "upgrade", new ItemStack(ModItems.speedUpgradeTier), "FRF", "NGN", "FRF", 'F', Items.field_151008_G, 'N', Items.field_151074_bl, 'R', Items.field_151137_ax, 'G', ModItems.circuitBoard);
        addShapedRecipes("speed_2_recipe", "upgrade", new ItemStack(ModItems.speedUpgradeTier, 1, 1), "OCO", "GRG", "QCQ", 'Q', Items.field_151128_bU, 'R', Blocks.field_150451_bX, 'C', Items.field_151137_ax, 'O', ModItems.circuitBoard, 'G', new ItemStack(ModItems.speedUpgradeTier));
        addShapedRecipes("speed_3_recipe", "upgrade", new ItemStack(ModItems.speedUpgradeTier, 1, 2), "OFO", "GRG", "QOQ", 'Q', Blocks.field_150371_ca, 'R', Items.field_151107_aW, 'F', Items.field_179556_br, 'O', ModItems.circuitBoard, 'G', new ItemStack(ModItems.speedUpgradeTier, 1, 1));
        addShapedRecipes("circuit_recipe", "upgrade", new ItemStack(ModItems.circuitBoard), "GGG", "PDP", "PPP", 'D', new ItemStack(Items.field_151100_aR, 1, 2), 'P', ModItems.plastic, 'G', Items.field_151074_bl);
        addShapedRecipes("seeds_1_recipe", "feed", new ItemStack(ModItems.chickenFeed, 9), "SFS", "FSF", "SFS", 'F', ModItems.featherMeal, 'S', Items.field_151014_N);
        addShapedRecipes("seeds_2_recipe", "feed", new ItemStack(ModItems.chickenFeed, 9), "SFS", "FSF", "SFS", 'F', ModItems.featherMeal, 'S', Items.field_151080_bb);
        addShapedRecipes("seeds_3_recipe", "feed", new ItemStack(ModItems.chickenFeed, 9), "SFS", "FSF", "SFS", 'F', ModItems.featherMeal, 'S', Items.field_151081_bc);
        addShapedRecipes("shredder_recipe", "machine", new ItemStack(ModBlocks.shredder), "I I", "ISI", "IRI", 'I', Items.field_151042_j, 'R', Blocks.field_150451_bX, 'S', Items.field_151048_u);
        addShapedRecipes("fiberpad_recipe", "held", new ItemStack(ModItems.fiberPad), "fff", "fff", "fff", 'f', ModItems.featherFiber);
        addShapedRecipes("string_recipe", "held", new ItemStack(Items.field_151007_F), "  f", " f ", "f  ", 'f', ModItems.featherFiber);
        addShapedRecipes("wool_recipe", "held", new ItemStack(Blocks.field_150325_L, 8), "fff", "fff", "fff", 'f', ModItems.fiberPad);
        addShapedOreRecipe("sprayer_recipe", "held", new ItemStack(ModItems.sprayer), new Object[] { "DD ", " IB", "IGI", 'I', "ingotIron", 'G', Items.field_151133_ar, 'D', "ingotIron", 'B', new ItemStack(Blocks.field_150430_aB) });
        addShapelessRecipes("mealpulp_recipe", "held", new ItemStack(ModItems.mealPulp, 4), new ItemStack(ModItems.featherMeal), new ItemStack(ModItems.featherMeal), new ItemStack(ModItems.featherMeal), new ItemStack(ModItems.featherMeal), new ItemStack(ModItems.featherMeal), new ItemStack(ModItems.featherMeal), new ItemStack(ModItems.featherMeal), new ItemStack(ModItems.featherMeal), new ItemStack(Items.field_151131_as));
        addShapelessRecipes("egg_null_recipe", "held", new ItemStack(Items.field_151110_aK), ModItems.hatcheryEgg);
        GameRegistry.addSmelting(ModItems.featherFiber, new ItemStack(ModItems.plastic), 0.0f);
        GameRegistry.addSmelting(ModItems.mealPulp, new ItemStack(Items.field_151121_aF), 0.0f);
    }
    
    public static void addShapedRecipes(final String registryname, final String group, final ItemStack result, final Object... recipe) {
        final CraftingHelper.ShapedPrimer primer = CraftingHelper.parseShaped(recipe);
        addToList((IRecipe)new ShapedRecipes(group.toString(), primer.height, primer.width, primer.input, result).setRegistryName(new ResourceLocation("hatchery", registryname)));
    }
    
    public static void addShapedOreRecipe(final String registryname, final String group, final ItemStack result, final Object[] recipe) {
        addToList((IRecipe)new ShapedOreRecipe(new ResourceLocation("hatchery", group), result, recipe).setRegistryName(new ResourceLocation("hatchery", registryname)));
    }
    
    protected static void addShapelessRecipes(final String registryname, final String group, final ItemStack result, final Item input) {
        final NonNullList<Ingredient> ingrediate = (NonNullList<Ingredient>)NonNullList.func_191196_a();
        ingrediate.add((Object)IgnoreNBTIngredient.fromStacks(new ItemStack[] { new ItemStack(input, 1, 32767) }));
        addToList((IRecipe)new ShapelessRecipes(group.toString(), result, (NonNullList)ingrediate).setRegistryName(new ResourceLocation("hatchery", registryname)));
    }
    
    public static void addShapelessRecipes(final String registryname, final String group, final ItemStack result, final ItemStack... ingredints) {
        final NonNullList<Ingredient> list = (NonNullList<Ingredient>)NonNullList.func_191196_a();
        for (final ItemStack input : ingredints) {
            list.add((Object)Ingredient.func_193369_a(new ItemStack[] { input }));
        }
        addToList((IRecipe)new ShapelessRecipes(group.toString(), result, (NonNullList)list).setRegistryName(new ResourceLocation("hatchery", registryname)));
    }
    
    public static IRecipe addToList(final IRecipe recipe) {
        ModRecipes.RECIPELIST.add(recipe);
        return recipe;
    }
    
    @SubscribeEvent
    public static void registerRecipes(final RegistryEvent.Register<IRecipe> event) {
        ModRecipes.recipeRegistry = (IForgeRegistry<IRecipe>)event.getRegistry();
        initRecipes();
        ShredderTileEntity.registerShredderRecipes();
        for (final IRecipe recipe : ModRecipes.RECIPELIST) {
            ModRecipes.recipeRegistry.register((IForgeRegistryEntry)recipe);
        }
    }
    
    static {
        ModRecipes.RECIPELIST = new ArrayList<IRecipe>();
    }
}
